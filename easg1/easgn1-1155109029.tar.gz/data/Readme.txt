- This program should be running on Linux, not Unix.

- Run "make" to compile.

- Using two terminals: one as the client and another one as the server.

- Start the server first. E.g., "./server 12345"

- Then, start the client, E.g., "./client 127.0.0.1 12345" if your 
server is running on the same machine as the client.
