Source code:
    - rsa.cc
        - Test the RSA algorithms
        - Example: 
          % ./rsa 12345678

    - rsa_pem.cc
        - Test how to read RSA parameters from file
        - Example:
          % ./rsa_pem rsa1024.pem rsa1024_pub.pem

